package com.example.hellotoby;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.os.BatteryManager;
import android.widget.Toast;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class PowerConnectionReceiver extends BroadcastReceiver {
    String msg = "connection reciever module debug message: ";
    public void onReceive(Context context, Intent intent){
        Log.d(msg, "tripped the message recieved in reciever");
        CharSequence iData =intent.getDataString();
        Toast.makeText(context,"DataFlair Received Message: "+iData,Toast.LENGTH_LONG).show();
    }


}
