package com.example.hellotoby;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.os.BatteryManager;
import android.widget.Toast;
import android.content.Intent;



public class MainActivity extends Activity {
   String msg = "Android : ";
   
   /** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);
      Log.d(msg, "The onCreate() and fFUCK YOUevent");
      Log.d(msg, "onCreate: ");
   }

   /** Called when the activity is about to become visible. */
   @Override
   protected void onStart() {
      super.onStart();
      Log.d(msg, "The onStartosastheysayinGREECE() event");
     // Toast.makeText(getApplicationContext(),"Hello FUCKYOUFUCKYOU",Toast.LENGTH_LONG).show();

   }

   /** Called when the activity has become visible. */
   @Override
   protected void onResume() {
      super.onResume();
      Log.d(msg, "The onResume() ON rez-you-me event");
   }

   /** Called when another activity is taking focus. */
   @Override
   protected void onPause() {
      super.onPause();
      Log.d(msg, "The onPause() event-event la-pause-e");
   }

   /** Called when the activity is no longer visible. */
   @Override
   protected void onStop() {
      super.onStop();
      Log.d(msg, "The onStop() event FOOKIN StOOOOOP!");
   }

   /** Called just before the activity is destroyed. */
   @Override
   public void onDestroy() {
      super.onDestroy();
      Log.d(msg, "The onDestroy() event Do we get to see destroy do we do we do we");
   }

}