package com.example.hellotoby;

public class Config {
    public static final String EMAIL ="wompusi@gmail.com";
    public static final String PASSWORD ="TGIl2rh4w";
    public static final String PASSWORDGmail ="uyyximhcqqwuaopq";
}
