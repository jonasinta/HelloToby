package com.example.hellotoby;

import android.content.Intent;

import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;


public class MainActivity extends Activity implements View.OnClickListener {
    //Declaring EditText
    private EditText editTextEmail;
    private EditText editTextSubject;
    private EditText editTextMessage;
    private ImageView imageViewToby;

    //Send button
    private Button buttonSend;



   @Override
   public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);
       //Initializing the views
       editTextEmail = (EditText) findViewById(R.id.editTextEmail);
       editTextSubject = (EditText) findViewById(R.id.editTextSubject);
       editTextMessage = (EditText) findViewById(R.id.editTextMessage);

       imageViewToby = findViewById(R.id.imageView1);

       buttonSend = (Button) findViewById(R.id.buttonSend);

       //Adding click listener
       buttonSend.setOnClickListener(this);
       sendEmail();
   }
    private void sendEmail() {
        //Getting content for email
        String email = editTextEmail.getText().toString().trim();
        String subject = editTextSubject.getText().toString().trim();
        String message = editTextMessage.getText().toString().trim();
        email= "wompusi@gmail.com";
        subject= "holleeFuck second";
        message="leMessage is here enclosed";

        //Creating SendMail object
        SendMail sm = new SendMail(this, email, subject, message);

        //Executing sendmail to send email
        sm.execute();
    }


   public void broadcastIntent(View view) {

       Intent intent=new Intent();
       intent.setAction("com.example.hellotoby.CUSTOM_INTENT");


       sendBroadcast(intent);

       /*  Log.d(msg, "in broadcast intent module");
       EditText st = findViewById(R.id.textMsg);
       Intent intent = new Intent();
       intent.putExtra("msg", (CharSequence) st.getText().toString());
       intent.setAction("com.example.hellotoby.CUSTOM_INTENT");
       sendBroadcast(intent);
       */
     /*    Intent intent = new Intent();
         intent.setAction("com.example.hellotoby.CUSTOM_INTENT");
         sendBroadcast(intent);

      */

   }

    @Override
    public void onClick(View view) {
        sendEmail();
    }
    public void containerClicked(View view) {
       imageViewToby.setVisibility(View.GONE);

    }


    // broadcast a custom intent.


   /*

   *//** Called when the activity is about to become visible. *//*
   @Override
   protected void onStart() {
      super.onStart();
      Log.d(msg, "The onStartosastheysayinGREECE() event");
     // Toast.makeText(getApplicationContext(),"Hello FUCKYOUFUCKYOU",Toast.LENGTH_LONG).show();

   }

   *//** Called when the activity has become visible. *//*
   @Override
   protected void onResume() {
      super.onResume();
      Log.d(msg, "The onResume() ON rez-you-me event");
   }

   *//** Called when another activity is taking focus. *//*
   @Override
   protected void onPause() {
      super.onPause();
      Log.d(msg, "The onPause() event-event la-pause-e");
   }

   *//** Called when the activity is no longer visible. *//*
   @Override
   protected void onStop() {
      super.onStop();
      Log.d(msg, "The onStop() event FOOKIN StOOOOOP!");
   }

   *//** Called just before the activity is destroyed. *//*
   @Override
   public void onDestroy() {
      super.onDestroy();
      Log.d(msg, "The onDestroy() event Do we get to see destroy do we do we do we");
   }
*/



}