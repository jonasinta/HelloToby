package com.example.hellotoby;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

public class PowerConnectionReceiver extends BroadcastReceiver {
    String msg = "Android : ";
    private String[] sendAddress;
private Context contextSpreader;
private Intent intent4class;
    @Override
    public void onReceive(Context context, Intent intent) {
        contextSpreader = context;
        intent4class = intent;
        Resources res = context.getResources();
        sendAddress = res.getStringArray(R.array.addressess);
        Toast toast = Toast.makeText(context, intent.getAction(), Toast.LENGTH_LONG);

        toast.setGravity(Gravity.TOP|Gravity.LEFT, 0, 0);
        toast.show();
        composeEmail(sendAddress, "holy shit");



        Log.d("YAY", "in broadcast intent module");
      //  throw new UnsupportedOperationException("Not yet implemented");
    }
    public void composeEmail(String[] addresses, String subject) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_SUBJECT, intent4class.getAction());
        intent.putExtra(Intent.EXTRA_TEXT, "um what happened is: "+intent4class.getAction());
        if (intent.resolveActivity(contextSpreader.getPackageManager()) != null) {
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            contextSpreader.startActivity(intent);
        }
        else Log.e(msg, "composeEmail: fail badly no client " );
    }


}
